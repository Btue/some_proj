function hideBox(){
	var wind = $(window).width(),
		block_w = $(".information_box").width(),
		hov = Math.floor(wind/block_w);
		$(".information_box:lt(" + hov + ")" , ".wrap").addClass('active');
		$(".information_box:gt(" + (hov-1) + ")" , ".wrap").hide();
}
$(document).ready(function() {
	$(".information_text").each(function(index, el) {
		var $this = $(this),
			$par = $this.closest('.information_box'),
			$but_par = $(".buttonShow",$par),
			$but = $(".button_text",$par);
		$this.height() > 250 ? $par.addClass('showBox')	: $but_par.remove();
		$but.attr("data-show") == "false" ? $but.text($but.attr("data-showMes")) : $but.text($but.attr("data-hideMess"));
	});


	hideBox();
	$(".buttonShow").click(function(e) {
		var $this = $(this),
			$par = $this.closest(".information_box"),
			$button = $(".button_text",$par);
			$par.toggleClass('showBox');
			$button.attr("data-show",$button.attr("data-show") == "false" ? true : false);
			$button.attr("data-show") == "false" ? $button.text($button.attr("data-showMes")) : $button.text($button.attr("data-hideMess"));
	});

	$(".buttonCatalog").click(function(e) {

		var open_list = $(".wrap").find(".information_box.active").length;
		$(".information_box:lt(" + (open_list + 2) + ")" , ".wrap").show().addClass('active');
		if(open_list + 2 >= $(".wrap").find(".information_box").length){
			$(".buttonCatalog").hide();
		}	
	});

	// $(document).mouseup(function (e){
	// 	var div = $(".menu_list"); 
	// 	if(!$(e.target).hasClass('show_box')){
	// 		if (!div.is(e.target) && div.has(e.target).length === 0) {
	// 			div.slideUp(200); 
	// 			// close();
	// 			// offClick();
	// 		}
	// 	}
	// });
});